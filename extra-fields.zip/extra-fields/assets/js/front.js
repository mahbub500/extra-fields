let ef_modal = ( show = true ) => {
	if(show) {
		jQuery('#extra-fields-modal').show();
	}
	else {
		jQuery('#extra-fields-modal').hide();
	}
}

jQuery(function($){
	
})